"""Generate final_report.pdf for the SER216 Final Project."""
from fpdf import FPDF
from pathlib import Path

ROOT = Path("/Users/shahzod/abdulazizfinal")
OUT = ROOT / "final_report.pdf"
DIAGRAM = ROOT / "diagrams" / "workflow_diagram.png"


class Report(FPDF):
    def header(self):
        if self.page_no() == 1:
            return
        self.set_font("Helvetica", "I", 9)
        self.set_text_color(120, 120, 120)
        self.cell(0, 8, "SER216 Final Project - Digital Parking Permit System",
                 align="R", new_x="LMARGIN", new_y="NEXT")
        self.set_text_color(0, 0, 0)
        self.ln(2)

    def footer(self):
        self.set_y(-15)
        self.set_font("Helvetica", "I", 9)
        self.set_text_color(120, 120, 120)
        self.cell(0, 10, f"Page {self.page_no()}", align="C")
        self.set_text_color(0, 0, 0)


def h1(pdf, text):
    pdf.set_font("Helvetica", "B", 18)
    pdf.set_text_color(20, 60, 130)
    pdf.cell(0, 12, text, new_x="LMARGIN", new_y="NEXT")
    pdf.set_text_color(0, 0, 0)
    pdf.ln(2)


def h2(pdf, text):
    pdf.set_font("Helvetica", "B", 14)
    pdf.set_text_color(20, 60, 130)
    pdf.cell(0, 9, text, new_x="LMARGIN", new_y="NEXT")
    pdf.set_text_color(0, 0, 0)
    pdf.ln(1)


def h3(pdf, text):
    pdf.set_font("Helvetica", "B", 12)
    pdf.cell(0, 7, text, new_x="LMARGIN", new_y="NEXT")
    pdf.ln(1)


def body(pdf, text):
    pdf.set_font("Helvetica", "", 11)
    pdf.multi_cell(0, 5.6, text, new_x="LMARGIN", new_y="NEXT")
    pdf.ln(1)


def bullet(pdf, text):
    pdf.set_font("Helvetica", "", 11)
    pdf.cell(6)
    pdf.cell(4, 5.6, "-")
    pdf.multi_cell(0, 5.6, text, new_x="LMARGIN", new_y="NEXT")


def kv(pdf, key, value, key_w=42):
    pdf.set_font("Helvetica", "B", 11)
    start_x = pdf.get_x()
    start_y = pdf.get_y()
    pdf.multi_cell(key_w, 5.6, key, new_x="RIGHT", new_y="TOP")
    end_y_key = pdf.get_y()
    pdf.set_xy(start_x + key_w, start_y)
    pdf.set_font("Helvetica", "", 11)
    pdf.multi_cell(pdf.w - pdf.r_margin - (start_x + key_w), 5.6, value,
                   new_x="LMARGIN", new_y="NEXT")
    end_y_val = pdf.get_y()
    pdf.set_y(max(end_y_key, end_y_val))


def table(pdf, headers, rows, widths):
    pdf.set_font("Helvetica", "B", 10)
    pdf.set_fill_color(20, 60, 130)
    pdf.set_text_color(255, 255, 255)
    line_h = 6.5
    for h_, w_ in zip(headers, widths):
        pdf.cell(w_, line_h, h_, border=1, align="C", fill=True)
    pdf.ln(line_h)
    pdf.set_text_color(0, 0, 0)
    pdf.set_font("Helvetica", "", 9.5)
    fill = False
    for row in rows:
        # Compute the height needed for this row.
        heights = []
        for cell, w_ in zip(row, widths):
            n_lines = pdf.multi_cell(w_, 5, cell, dry_run=True, output="LINES")
            heights.append(len(n_lines) * 5)
        row_h = max(heights)
        # Draw cells.
        x0 = pdf.get_x()
        y0 = pdf.get_y()
        if y0 + row_h > pdf.h - pdf.b_margin:
            pdf.add_page()
            x0 = pdf.get_x()
            y0 = pdf.get_y()
        if fill:
            pdf.set_fill_color(238, 244, 255)
        else:
            pdf.set_fill_color(255, 255, 255)
        for cell, w_ in zip(row, widths):
            x_before = pdf.get_x()
            y_before = pdf.get_y()
            pdf.multi_cell(w_, 5, cell, border=1, fill=True)
            pdf.set_xy(x_before + w_, y_before)
        pdf.ln(row_h)
        fill = not fill


pdf = Report(format="A4")
pdf.set_auto_page_break(auto=True, margin=18)
pdf.set_margins(left=18, top=18, right=18)

# COVER PAGE
pdf.add_page()
pdf.ln(40)
pdf.set_font("Helvetica", "B", 26)
pdf.set_text_color(20, 60, 130)
pdf.multi_cell(0, 12, "SER216 Final Project Report",
               align="C", new_x="LMARGIN", new_y="NEXT")
pdf.ln(4)
pdf.set_font("Helvetica", "B", 18)
pdf.set_text_color(0, 0, 0)
pdf.multi_cell(0, 10, "Digital Parking Permit System",
               align="C", new_x="LMARGIN", new_y="NEXT")
pdf.ln(40)
pdf.set_font("Helvetica", "", 13)
pdf.multi_cell(0, 8, "Student: Abdulaziz Maxammadjonov",
               align="C", new_x="LMARGIN", new_y="NEXT")
pdf.multi_cell(0, 8, "Course: SER216 - Software Engineering",
               align="C", new_x="LMARGIN", new_y="NEXT")
pdf.multi_cell(0, 8, "Date: 2026-05-04",
               align="C", new_x="LMARGIN", new_y="NEXT")
pdf.ln(12)
pdf.set_font("Helvetica", "I", 11)
pdf.set_text_color(80, 80, 80)
pdf.multi_cell(0, 7,
    "Repository: github.com/adizuco/SER216_Final_Project_Abdlaziz_Maxammadjonov",
    align="C", new_x="LMARGIN", new_y="NEXT")
pdf.set_text_color(0, 0, 0)

# 1 INTRODUCTION
pdf.add_page()
h1(pdf, "1. Introduction")
body(pdf,
    "A university wants a digital parking permit system. Students and staff "
    "register vehicles, request parking permits, check available parking "
    "zones, and report parking issues. Security staff verify permits and "
    "update violation records.")
body(pdf,
    "This report presents the requirements, workflow, test plan, and defect "
    "analysis for the proposed system, along with the GitHub evidence that "
    "demonstrates a complete development workflow (branch, commits, pull "
    "request, merge).")

# 2 REQUIREMENTS
h1(pdf, "2. Requirements")
h2(pdf, "2.1 Functional Requirements")
h3(pdf, "FR1 - Vehicle Registration")
body(pdf,
    "The system shall allow students and staff to register a vehicle by "
    "providing the license plate number, make, model, color, and owner ID. "
    "Each user may register up to three vehicles per academic year.")
h3(pdf, "FR2 - Permit Request and Approval")
body(pdf,
    "The system shall allow a registered user to request a parking permit by "
    "selecting a permit type (student, staff, visitor) and a preferred "
    "parking zone. The request shall be reviewed and either approved or "
    "rejected by the parking office, and the user shall be notified of the "
    "decision by email.")
h3(pdf, "FR3 - Real-Time Zone Availability")
body(pdf,
    "The system shall display the live availability (free / occupied / "
    "reserved) of every campus parking zone so that users can choose a zone "
    "with open spaces before submitting a permit request.")
h3(pdf, "FR4 - Permit Verification by Security")
body(pdf,
    "The system shall allow security staff to scan a vehicle's license plate "
    "or permit QR code and instantly verify whether the displayed permit is "
    "valid, expired, or revoked, and to record any violation directly into "
    "the user's record.")

h2(pdf, "2.2 Non-Functional Requirements")
h3(pdf, "NFR1 - Performance")
body(pdf,
    "The system shall respond to a permit verification scan in under 2 "
    "seconds, even when up to 500 verifications are performed concurrently "
    "across campus during peak hours.")
h3(pdf, "NFR2 - Security")
body(pdf,
    "All personal data (license plates, owner IDs, payment data) shall be "
    "transmitted over HTTPS and stored encrypted at rest using AES-256. Only "
    "authenticated parking-office and security staff shall be allowed to "
    "view or modify permit records.")

# 3 WORKFLOW DIAGRAM
pdf.add_page()
h1(pdf, "3. Workflow Diagram")
body(pdf,
    "The diagram below shows the end-to-end workflow of the Digital Parking "
    "Permit System: Vehicle Registration -> Permit Request -> Zone Check -> "
    "Permit Approval -> Parking Verification.")
if DIAGRAM.exists():
    page_w = pdf.w - pdf.l_margin - pdf.r_margin
    pdf.image(str(DIAGRAM), x=pdf.l_margin + 12, w=page_w - 24, h=210)
    pdf.set_font("Helvetica", "I", 10)
    pdf.set_text_color(80, 80, 80)
    pdf.multi_cell(0, 5, "Figure 1. Permit lifecycle from vehicle "
                   "registration through verification.",
                   align="C", new_x="LMARGIN", new_y="NEXT")
    pdf.set_text_color(0, 0, 0)

# 4 TEST CASE TABLE
pdf.add_page()
h1(pdf, "4. Test Case Table")
body(pdf,
    "Six test cases covering system, acceptance, and regression testing.")
headers = ["Test ID", "Feature", "Input / Data", "Expected Result", "Type"]
widths = [15, 28, 47, 56, 22]
rows = [
    ["TC-01",
     "End-to-end permit issuance",
     "Register vehicle ABC-123, request Student permit for Zone A "
     "(4 free spaces), parking office approves",
     "Permit is issued with a unique QR code, user receives approval email, "
     "Zone A free count decreases from 4 to 3",
     "System"],
    ["TC-02",
     "Permit verification under load",
     "Security scans 50 different valid permit QR codes within 10 seconds "
     "during peak hours",
     "All 50 scans return Valid in under 2 seconds, no timeouts or "
     "duplicates, audit log records all 50 events",
     "System"],
    ["TC-03",
     "Student requests staff permit",
     "Registered student logs in, selects Staff permit type for Zone B",
     "System rejects the request with a clear message - business rule "
     "for permit type is enforced",
     "Acceptance"],
    ["TC-04",
     "Security reports a violation",
     "Security scans an unregistered plate XYZ-999 and adds note "
     "'No permit displayed'",
     "System creates a violation record marked Pending Review and notifies "
     "the parking office",
     "Acceptance"],
    ["TC-05",
     "Re-verify zone availability",
     "After fixing a defect that miscounted occupied spaces, run the Zone A "
     "availability check with 2 cars parked",
     "System reports 2 occupied / correct free count - earlier counting bug "
     "stays fixed",
     "Regression"],
    ["TC-06",
     "Re-verify permit expiry logic",
     "After fixing the timezone bug, scan a permit issued today that "
     "expires next semester",
     "System returns Valid regardless of the device timezone - earlier "
     "expiry defect stays fixed",
     "Regression"],
]
table(pdf, headers, rows, widths)
pdf.ln(2)
body(pdf,
    "System tests (TC-01, TC-02) check the complete integrated system "
    "end-to-end. Acceptance tests (TC-03, TC-04) check whether the system "
    "meets user and business expectations. Regression tests (TC-05, TC-06) "
    "re-verify previously fixed defects so they do not reappear after later "
    "changes.")

# 5 DEFECT ANALYSIS
pdf.add_page()
h1(pdf, "5. Defect Analysis")
pdf.set_font("Helvetica", "I", 11)
pdf.multi_cell(0, 6,
    'Defect: "A valid parking permit is shown as expired during '
    'security verification."',
    new_x="LMARGIN", new_y="NEXT")
pdf.ln(2)

defect_rows = [
    ("Defect category",
     "Functional defect - incorrect business logic. The system returns "
     "the wrong status (Expired) for a record whose stored expiry date "
     "is still in the future. Not a UI defect (message renders correctly) "
     "and not a performance defect (response time is fine); the underlying "
     "decision is wrong."),
    ("Severity",
     "High. The core promise of the system - telling security whether a "
     "permit is valid right now - is broken. A valid customer is wrongly "
     "flagged, which can lead to a false violation, customer complaints, "
     "and loss of trust. It does not crash the system, so it is not "
     "Critical, but it directly blocks a primary use case."),
    ("Priority",
     "High (P1). The defect happens during live security verification and "
     "is visible to end users in real time. It must be fixed before the "
     "next release; a hotfix is appropriate. The manual workaround "
     "(overriding the check by hand) is slow and error-prone, so the fix "
     "cannot wait."),
    ("Possible root cause",
     "Most likely a timezone / date-comparison bug in the verification "
     "service: the permit's expires_at is stored in UTC but compared "
     "against the security device's local time (or vice versa), so a "
     "permit that expires at midnight UTC is reported as expired several "
     "hours early in a positive UTC offset. Other possibilities: the "
     "expiry field is a string and is being compared lexically rather "
     "than as a date; a recent migration shifted dates by one day due to "
     "a date vs datetime cast; an old expired record is being served "
     "from cache after renewal."),
    ("Regression test",
     "Re-run TC-06 after the fix: scan a permit issued today that "
     "expires next semester, on devices set to multiple timezones "
     "(UTC, UTC+5, UTC-8). Expected result is Valid on every device. "
     "Add this test to the automated regression suite so the defect "
     "cannot silently return after a future change."),
]
for k, v in defect_rows:
    kv(pdf, k, v)
    pdf.ln(2)

h2(pdf, "Recommended Fix Workflow")
for step in [
    "Reproduce the defect against a copy of production data with at least "
    "one near-expiry permit.",
    "Inspect the verification service's expiry comparison - confirm both "
    "sides are timezone-aware datetime values.",
    "Patch the comparison to always evaluate in UTC, or use a "
    "database-level comparison so the database engine handles timezones "
    "consistently.",
    "Add unit tests covering UTC, positive offsets, negative offsets, and "
    "the day-boundary edge case.",
    "Add the regression test (TC-06) to the CI pipeline.",
    "Deploy as a hotfix and monitor the verification audit log for any "
    "recurrence over the next 7 days.",
]:
    bullet(pdf, step)

# 6 GITHUB EVIDENCE
pdf.add_page()
h1(pdf, "6. GitHub Evidence")
body(pdf,
    "The full development workflow is captured in the GitHub repository "
    "for this project. The required evidence is summarized below; "
    "screenshots are stored in the screenshots/ folder of the repository.")

h2(pdf, "Required Evidence Checklist")
for item in [
    "Repository created: SER216_Final_Project_Abdlaziz_Maxammadjonov",
    "README.md added with project description, tools, structure, and workflow",
    "Project files uploaded: report PDF, workflow diagram PNG, test cases CSV, defect analysis, screenshots",
    "Feature branch created: feature/parking-permit-system",
    "At least 3 meaningful commits made on the feature branch",
    "Pull request opened from feature branch into main",
    "Pull request reviewed and merged into main",
    "Final PDF uploaded to the repository at the root",
]:
    bullet(pdf, item)
pdf.ln(2)

h2(pdf, "Repository Link")
pdf.set_font("Helvetica", "", 11)
pdf.set_text_color(20, 60, 130)
pdf.multi_cell(0, 6,
    "https://github.com/adizuco/SER216_Final_Project_Abdlaziz_Maxammadjonov",
    new_x="LMARGIN", new_y="NEXT")
pdf.set_text_color(0, 0, 0)

h2(pdf, "Commit Examples")
for c in [
    "docs: update README with full project description and structure",
    "feat: add functional and non-functional requirements",
    "feat: add workflow diagram (Mermaid + PNG)",
    "feat: add test case table covering system, acceptance, regression",
    "feat: add defect analysis for expired-permit issue",
    "docs: add final report PDF",
]:
    bullet(pdf, c)

# 7 CONCLUSION
pdf.add_page()
h1(pdf, "7. Conclusion")
body(pdf,
    "The proposed Digital Parking Permit System covers vehicle registration, "
    "permit request and approval, real-time zone availability, and security "
    "verification with violation tracking. The four functional and two "
    "non-functional requirements together set out a system that is correct, "
    "fast under load, and secure with personal data.")
body(pdf,
    "The test plan combines system, acceptance, and regression cases so "
    "that integration, business value, and prior fixes are all verified "
    "before a release. The defect analysis for the 'valid permit shown as "
    "expired' issue points strongly at a timezone bug in the verification "
    "service and prescribes both a hotfix path and a regression test that "
    "stops the defect from returning.")
body(pdf,
    "All deliverables and supporting evidence are version-controlled on "
    "GitHub, with branch, commit, and pull-request history demonstrating "
    "a complete software-engineering workflow.")

pdf.output(str(OUT))
print(f"Wrote {OUT}")
